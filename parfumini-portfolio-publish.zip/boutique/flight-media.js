// Assemble the video locally so scrubbing works even when the CDN serves whole files.
const flightStatus = document.getElementById("flight-status");
const flightParts = 12;
let flightLoadStarted = false;

async function loadFlight() {
  if (flightLoadStarted || reducedMotion.matches) return;
  flightLoadStarted = true;
  flightStatus.textContent = "Загружается пролёт";
  flightStatus.hidden = false;
  try {
    const parts = await Promise.all(Array.from({ length: flightParts }, async (_, index) => {
      const filename = String(index).padStart(2, "0");
      const response = await fetch(`assets/gallery/flight-web/${filename}.bin`);
      if (!response.ok) throw new Error(`Video part ${filename}: ${response.status}`);
      return response.blob();
    }));
    flight.addEventListener("loadeddata", () => { flightStatus.hidden = true; }, { once: true });
    flight.src = URL.createObjectURL(new Blob(parts, { type: "video/mp4" }));
  } catch {
    flight.dispatchEvent(new Event("error"));
  }
}

flight.addEventListener("error", () => {
  flightStatus.hidden = false;
  flightStatus.textContent = "Видео недоступно. Можно перейти к полке.";
});
reducedMotion.addEventListener("change", loadFlight);
loadFlight();
