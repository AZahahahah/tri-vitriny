const canvas = document.getElementById("flight");
const context = canvas.getContext("2d", { alpha: false });
const status = document.getElementById("flight-status");
const segmentLength = 4;
const segmentCount = 10;
const segments = new Map();
const video = document.createElement("video");
video.muted = true;
video.defaultMuted = true;
video.playsInline = true;
video.preload = "auto";
video.className = "flight-decoder";
canvas.after(video);

let wantedTime = 0;
let currentSegment = -1;
let switching = false;
let loadingNotice;
let paintedTime = 0;

function loadSegment(index) {
  if (index < 0 || index >= segmentCount) return;
  if (segments.has(index)) return segments.get(index);

  const filename = String(index).padStart(2, "0");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 18000);
  const file = fetch(`assets/gallery/segments/${filename}.mp4`, { signal: controller.signal })
    .then(response => {
      if (!response.ok) throw new Error(`Segment ${filename}: ${response.status}`);
      return response.blob();
    })
    .then(blob => URL.createObjectURL(blob))
    .finally(() => clearTimeout(timeout));
  file.catch(() => { if (segments.get(index) === file) segments.delete(index); });
  segments.set(index, file);
  return file;
}

function showLoading() {
  if (loadingNotice) return;
  loadingNotice = setTimeout(() => {
    status.textContent = "Загружается фрагмент пролёта";
    status.hidden = false;
  }, 300);
}

function hideLoading() {
  clearTimeout(loadingNotice);
  loadingNotice = undefined;
  status.hidden = true;
}

function showFallback() {
  switching = false;
  hideLoading();
  scene.dataset.video = "unavailable";
  status.textContent = "Пролёт недоступен. Галерею и полку можно посмотреть дальше.";
  status.hidden = false;
  scheduleRender();
}

function paint() {
  if (video.readyState < 2 || video.seeking || Math.abs(currentSegment * segmentLength + video.currentTime - wantedTime) > .15) return;
  context.drawImage(video, 0, 0, canvas.width, canvas.height);
  canvas.dataset.ready = "true";
  paintedTime = currentSegment * segmentLength + video.currentTime;
  hideLoading();
  scheduleRender();
}

function move() {
  const index = Math.min(segmentCount - 1, Math.floor(wantedTime / segmentLength));
  if (switching) return;
  if (index !== currentSegment) {
    switching = true;
    showLoading();
    loadSegment(index).then(url => {
      switching = false;
      if (index !== Math.floor(wantedTime / segmentLength)) {
        move();
        return;
      }
      currentSegment = index;
      video.src = url;
      loadSegment(index + 1);
      loadSegment(index - 1);
    }).catch(() => {
      if (index === Math.floor(wantedTime / segmentLength)) showFallback();
      else {
        switching = false;
        move();
      }
    });
    return;
  }

  if (video.readyState < 1 || video.seeking) return;
  const time = Math.min(wantedTime - index * segmentLength, video.duration - .035);
  if (Math.abs(time - video.currentTime) > .02) video.currentTime = time;
  else if (Math.abs(paintedTime - (index * segmentLength + video.currentTime)) > .015 || !canvas.dataset.ready) paint();
}

video.addEventListener("loadedmetadata", move);
video.addEventListener("loadeddata", move);
video.addEventListener("seeked", move);
video.addEventListener("error", showFallback);
window.galleryFlight = {
  seek(time) {
    wantedTime = time;
    move();
  },
  get paintedTime() { return paintedTime; },
};
scheduleRender();
