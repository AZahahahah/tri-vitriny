const groups = [
  { label: "Все", traits: [] },
  { label: "Древесные", traits: ["Древесный"] },
  { label: "Цветочные", traits: ["Цветочный"] },
  { label: "Свежие", traits: ["Свежий", "Цитрусовый", "Зелёный", "Чистый"] },
  { label: "Фруктовые", traits: ["Фруктовый"] },
  { label: "Тёплые", traits: ["Амбровый", "Ванильный", "Бальзамический", "Медовый", "Смолистый"] },
];

const prices = new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 });
const price = amount => prices.format(amount);
const search = document.getElementById("search");
const filterBar = document.getElementById("filters");
const productGrid = document.getElementById("products");
const count = document.getElementById("result-count");
const empty = document.getElementById("empty");
const details = document.getElementById("details");
const [detailImage, detailHouse, detailName, detailNotes, detailDescription, detailPrice, detailVolumes] =
  ["image", "house", "name", "notes", "description", "price", "volumes"].map(key => document.getElementById(`detail-${key}`));

let activeGroup = groups[0];
let activeCard;

function searchText(value) {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replaceAll("ё", "е");
}

function showDetails(fragrance, card) {
  activeCard = card;
  const image = new Image();
  image.src = `assets/catalog/${fragrance.id}.webp`;
  image.alt = `Флакон ${fragrance.name}`;
  detailImage.dataset.finish = fragrance.finish;
  detailImage.replaceChildren(image);
  detailHouse.textContent = fragrance.house;
  detailName.textContent = fragrance.label;
  detailNotes.textContent = fragrance.traits.join(" · ");
  detailDescription.textContent = fragrance.description;
  detailPrice.textContent = price(fragrance.bottlePrice);
  detailVolumes.replaceChildren(...[2, 5, 10].map((volume, index) => {
    const item = document.createElement("li");
    item.innerHTML = `<img src="assets/decant-${volume}.webp" alt=""><span>${volume} мл</span><strong>${price(fragrance.prices[index])}</strong>`;
    return item;
  }));
  details.showModal();
}

const filters = groups.map(group => {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = group.label;
  button.addEventListener("click", () => {
    activeGroup = group;
    render();
  });
  filterBar.append(button);
  return { button, group };
});

const cards = fragrances.map(fragrance => {
  const item = document.createElement("article");
  item.className = "product";
  item.dataset.finish = fragrance.finish;
  item.innerHTML = `
    <button type="button" class="product-button">
      <span class="product-image"><img src="assets/catalog/${fragrance.id}.webp" alt="" loading="lazy"></span>
      <span class="product-text">
        <span class="house"></span>
        <span class="product-name"></span>
        <span class="notes"></span>
        <span class="product-bottom">
          <span>2 мл · <strong></strong></span>
          <span class="product-open" aria-hidden="true">↗</span>
        </span>
      </span>
    </button>`;
  const button = item.querySelector("button");
  button.setAttribute("aria-label", `Подробнее о ${fragrance.name}`);
  item.querySelector(".house").textContent = fragrance.house;
  item.querySelector(".product-name").textContent = fragrance.label;
  item.querySelector(".notes").textContent = fragrance.traits.slice(0, 2).join(" · ");
  item.querySelector("strong").textContent = price(fragrance.prices[0]);
  button.addEventListener("click", () => showDetails(fragrance, button));
  productGrid.append(item);
  return {
    item,
    fragrance,
    searchable: searchText([fragrance.name, fragrance.house, fragrance.description, ...fragrance.traits].join(" ")),
  };
});

function render() {
  const query = searchText(search.value.trim());
  const words = query.split(/\s+/).filter(Boolean);
  let visible = 0;
  filters.forEach(({ button, group }) => button.setAttribute("aria-pressed", String(group === activeGroup)));
  cards.forEach(({ item, fragrance, searchable }) => {
    const inGroup = activeGroup.traits.length === 0 || fragrance.traits.some(trait => activeGroup.traits.includes(trait));
    const matches = inGroup && words.every(word => searchable.includes(word));
    item.hidden = !matches;
    visible += Number(matches);
  });
  count.textContent = `Найдено ${visible} из ${fragrances.length}`;
  empty.hidden = visible > 0;
}

search.addEventListener("input", render);
document.getElementById("clear-filters").addEventListener("click", () => {
  activeGroup = groups[0];
  search.value = "";
  render();
  search.focus();
});
details.querySelector(".close-detail").addEventListener("click", () => details.close());
details.addEventListener("close", () => activeCard.focus({ preventScroll: true }));
render();
