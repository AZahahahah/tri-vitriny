const journey = document.getElementById("journey");
const scene = document.getElementById("scene");
const ring = document.getElementById("wheel-ring");
const bottles = document.getElementById("bottles");
const product = document.getElementById("product");
const info = document.querySelector(".info");
const masthead = document.querySelector(".masthead");
const decants = document.getElementById("decants");
const previous = document.getElementById("previous");
const next = document.getElementById("next");
const positionLabel = document.getElementById("position");
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
const rubles = new Intl.NumberFormat("ru-RU");
const last = fragrances.length - 1;
const angleStep = 2 * Math.PI / fragrances.length;
journey.style.setProperty("--wheel-travel", `${last * 220}px`);

let active = -1;
let centerX = 0;
let centerY = 0;
let radius = 0;
let focusAngle = 0;
let viewportWidth = 0;
let viewportHeight = 0;
let scrollStart = 0;
let scrollDistance = 1;
let pendingFrame = 0;

const items = fragrances.map((fragrance, position) => {
  const bottle = document.createElement("button");
  const image = new Image();
  bottle.type = "button";
  bottle.className = "bottle";
  bottle.setAttribute("aria-label", fragrance.name);
  bottle.addEventListener("click", () => goTo(position));
  image.src = `assets/catalog/${fragrance.id}.webp`;
  image.alt = "";
  bottle.append(image);
  bottles.append(bottle);

  const panel = document.createElement("div");
  panel.className = "product-copy";
  panel.setAttribute("aria-hidden", "true");
  panel.innerHTML = `
    <p class="product-type">${fragrance.traits.join(" · ")}</p>
    <h2${fragrance.name.length > 20 ? ' class="long-name"' : ""}>${fragrance.name}</h2>
    <p class="description">${fragrance.description}</p>
    <p class="bottle-price"><span>Полный флакон</span> <strong>${rubles.format(fragrance.bottlePrice)} ₽</strong></p>`;
  product.append(panel);

  return { bottle, panel };
});

const offers = [2, 5, 10].map(volume => {
  const entry = document.createElement("li");
  entry.className = "decant";
  entry.innerHTML = `
    <div class="vial">
      <div class="vial-body">
        <img src="assets/decant-${volume}.webp" alt="">
        <span class="vial-label" aria-hidden="true"><span class="vial-mark"></span><span class="vial-name"></span></span>
      </div>
    </div>
    <span class="decant-volume">${volume} мл</span>
    <span class="decant-price"></span>`;
  decants.append(entry);
  return {
    entry,
    price: entry.querySelector(".decant-price"),
    mark: entry.querySelector(".vial-mark"),
    name: entry.querySelector(".vial-name"),
  };
});

function goTo(position) {
  const progress = Math.min(last, Math.max(0, position)) / last;
  window.scrollTo({
    top: scrollStart + scrollDistance * progress,
    behavior: reducedMotion.matches ? "instant" : "smooth",
  });
}

function render() {
  pendingFrame = 0;
  const progress = Math.min(1, Math.max(0, (window.scrollY - scrollStart) / scrollDistance)) * last;
  const selected = Math.round(progress);
  const wheelPosition = reducedMotion.matches ? selected : progress;

  items.forEach(({ bottle }, position) => {
    const angle = (position - wheelPosition) * angleStep;
    const distance = Math.min(Math.abs(position - wheelPosition), fragrances.length - Math.abs(position - wheelPosition));
    const emphasis = Math.max(0, 1 - distance) ** 2;
    const x = centerX + Math.cos(angle + focusAngle) * radius;
    const y = centerY + Math.sin(angle + focusAngle) * radius;
    const scale = 1 + 1.95 * emphasis;
    const visible = x >= 0 && x <= viewportWidth && y >= 28 && y <= viewportHeight - 28;
    bottle.tabIndex = visible ? 0 : -1;
    bottle.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%) scale(${scale})`;
    bottle.style.zIndex = String(1 + Math.round(emphasis * 100));
    bottle.style.setProperty("--bottle-light", String(.79 + .21 * emphasis));
  });

  if (selected === active) return;
  if (active >= 0) {
    items[active].bottle.removeAttribute("aria-current");
    items[active].panel.setAttribute("aria-hidden", "true");
  }

  active = selected;
  const fragrance = fragrances[active];
  items[active].bottle.setAttribute("aria-current", "true");
  items[active].panel.removeAttribute("aria-hidden");
  offers.forEach(({ entry, price, mark, name }, index) => {
    entry.dataset.finish = fragrance.finish;
    mark.textContent = fragrance.house;
    name.textContent = fragrance.label;
    price.textContent = `${rubles.format(fragrance.prices[index])} ₽`;
  });
  positionLabel.textContent = `${String(active + 1).padStart(2, "0")} / ${fragrances.length}`;
  previous.disabled = active === 0;
  next.disabled = active === last;
}

function requestRender() {
  if (!pendingFrame) pendingFrame = window.requestAnimationFrame(render);
}

function measure() {
  scrollStart = journey.getBoundingClientRect().top + window.scrollY;
  scrollDistance = Math.max(1, journey.offsetHeight - scene.offsetHeight);
  const stage = bottles.getBoundingClientRect();
  const focusY = (masthead.getBoundingClientRect().bottom + info.getBoundingClientRect().top) / 2 - stage.top;
  ring.style.setProperty("--bottle-focus", `${focusY}px`);
  const circle = ring.getBoundingClientRect();
  viewportWidth = stage.width;
  viewportHeight = stage.height;
  centerX = circle.left - stage.left + circle.width / 2;
  centerY = circle.top - stage.top + circle.height / 2;
  radius = circle.width / 2;
  focusAngle = Number(getComputedStyle(ring).getPropertyValue("--focus-angle")) * Math.PI / 180;
  requestRender();
}

previous.addEventListener("click", () => goTo(active - 1));
next.addEventListener("click", () => goTo(active + 1));
window.addEventListener("scroll", requestRender, { passive: true });
window.addEventListener("resize", measure);
new ResizeObserver(measure).observe(info);
reducedMotion.addEventListener("change", requestRender);
measure();
