const fragrances = [
  {
    name: "Рубин",
    family: "Цветочный",
    price: 8900,
    description: "Тёмная роза и терпкая малина на мягкой подложке из пачули.",
    notes: ["Роза", "Малина", "Пачули"],
    surface: "#241518",
    accent: "#ffae9f",
    image: "ruby",
  },
  {
    name: "Вуаль",
    family: "Мускусный",
    price: 7600,
    description: "Белый чай и рисовая пудра. Через несколько минут остаётся тёплый мускус.",
    notes: ["Белый чай", "Рис", "Мускус"],
    surface: "#24201a",
    accent: "#f3cd97",
    image: "veil",
  },
  {
    name: "Ирис",
    family: "Пудровый",
    price: 9200,
    description: "Прохладный ирис с фиалкой и лёгкой сухостью кедра.",
    notes: ["Ирис", "Фиалка", "Кедр"],
    surface: "#231c2c",
    accent: "#e0bceb",
    image: "iris",
  },
  {
    name: "Амбра",
    family: "Амбровый",
    price: 9700,
    description: "Апельсиновая цедра, густая амбра и ваниль с лёгкой дымностью.",
    notes: ["Апельсин", "Амбра", "Ваниль"],
    surface: "#2a1a15",
    accent: "#ffbe89",
    image: "amber",
  },
  {
    name: "Прилив",
    family: "Минеральный",
    price: 8200,
    description: "Грейпфрут, морская соль и древесина, нагретая на солнце.",
    notes: ["Грейпфрут", "Морская соль", "Ветивер"],
    surface: "#17222b",
    accent: "#acd5ef",
    image: "tide",
  },
  {
    name: "Сумрак",
    family: "Древесный",
    price: 10800,
    description: "Сухой кедр, чёрный перец и лёгкий дым ладана.",
    notes: ["Кедр", "Чёрный перец", "Ладан"],
    surface: "#232021",
    accent: "#efce9d",
    image: "dusk",
  },
];

const journey = document.getElementById("journey");
const scene = document.getElementById("scene");
const stage = document.getElementById("stage");
const bottles = document.getElementById("bottles");
const product = document.getElementById("product");
const index = document.getElementById("index");
const previous = document.getElementById("previous");
const next = document.getElementById("next");
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
const rubles = new Intl.NumberFormat("ru-RU");
const last = fragrances.length - 1;
const angleStep = 2 * Math.PI / fragrances.length;

let active = -1;
let stageWidth = 0;
let stageHeight = 0;
let scrollStart = 0;
let scrollDistance = 0;
let pendingFrame = 0;

const items = fragrances.map((fragrance, position) => {
  const bottle = document.createElement("div");
  const image = new Image();
  bottle.className = "bottle";
  image.src = `assets/${fragrance.image}.webp`;
  image.alt = "";
  bottle.append(image);
  bottles.append(bottle);

  const button = document.createElement("button");
  button.type = "button";
  button.textContent = String(position + 1).padStart(2, "0");
  button.setAttribute("aria-label", fragrance.name);
  button.addEventListener("click", () => goTo(position));
  index.append(button);

  const panel = document.createElement("div");
  const notes = fragrance.notes.map(note => `<li>${note}</li>`).join("");
  panel.innerHTML = `
    <p class="product-type">${fragrance.family} · 50 мл</p>
    <h2>${fragrance.name}</h2>
    <p class="description">${fragrance.description}</p>
    <ul class="notes" aria-label="Ноты">${notes}</ul>
    <p class="price">${rubles.format(fragrance.price)} ₽</p>`;

  return { bottle, button, panel };
});

function goTo(position) {
  const progress = Math.min(last, Math.max(0, position)) / last;
  window.scrollTo({
    top: scrollStart + scrollDistance * progress,
    behavior: reducedMotion.matches ? "instant" : "smooth",
  });
}

function render() {
  pendingFrame = 0;
  const progress = Math.min(1, Math.max(0, (window.scrollY - scrollStart) / scrollDistance)) * last;
  const selected = Math.round(progress);
  const wheelPosition = reducedMotion.matches ? selected : progress;

  items.forEach(({ bottle }, position) => {
    const angle = (position - wheelPosition) * angleStep;
    const depth = (Math.cos(angle) + 1) / 2;
    const x = Math.sin(angle) * stageWidth * .34;
    const y = (depth - 1) * stageHeight * .33;
    const scale = .32 + .68 * depth ** 2;
    bottle.style.transform = `translate(-50%, -50%) translate(${x}px, ${y}px) scale(${scale})`;
    bottle.style.zIndex = String(Math.round(depth * 100));
    bottle.style.opacity = String(.1 + .9 * depth ** 1.8);
  });

  if (selected === active) return;
  if (active >= 0) items[active].button.removeAttribute("aria-current");

  active = selected;
  const { surface, accent } = fragrances[active];
  scene.style.setProperty("--surface", surface);
  scene.style.setProperty("--accent", accent);
  items[active].button.setAttribute("aria-current", "true");
  product.replaceChildren(items[active].panel);
  previous.disabled = active === 0;
  next.disabled = active === last;
}

function requestRender() {
  if (!pendingFrame) pendingFrame = window.requestAnimationFrame(render);
}

function measure() {
  scrollStart = journey.getBoundingClientRect().top + window.scrollY;
  scrollDistance = Math.max(1, journey.offsetHeight - scene.offsetHeight);
  stageWidth = stage.clientWidth;
  stageHeight = stage.clientHeight;
  requestRender();
}

previous.addEventListener("click", () => goTo(active - 1));
next.addEventListener("click", () => goTo(active + 1));
window.addEventListener("scroll", requestRender, { passive: true });
window.addEventListener("resize", measure);
reducedMotion.addEventListener("change", requestRender);
measure();
