const journey = document.getElementById("arrival");
const scene = document.getElementById("scene");
const arrivalCaption = document.getElementById("arrival-caption");
const interiorCaption = document.getElementById("interior-caption");
const chapterLink = document.getElementById("chapter-link");
const catalog = document.getElementById("catalog");
const shelf = document.getElementById("shelf");
const descriptions = document.getElementById("descriptions");
const samples = document.getElementById("samples");
const previous = document.getElementById("previous");
const next = document.getElementById("next");
const counter = document.getElementById("counter");
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
const rubles = new Intl.NumberFormat("ru-RU");
const last = fragrances.length - 1;
const clamp = (value, min, max) => Math.max(min, Math.min(value, max));
const shelfTravel = last * 245;
const roomMoment = .837;
const shelfApproachStart = 33;
// Time into the final shot, shelf surface height, bottle scale, and spacing as a fraction of frame width.
const shelfTrack = [
  [1.72, .562, .10, .034], [2.25, .559, .16, .038], [2.75, .555, .22, .044],
  [3.2, .559, .24, .05], [3.8, .556, .28, .059], [4.4, .552, .34, .074], [4.94, .55, .43, .095],
  [5.44, .548, .60, .122], [5.94, .54, .78, .14], [6.44, .54, .92, .153], [7, .54, 1, .16],
];
journey.style.setProperty("--shelf-travel", `${shelfTravel}px`);
const priceText = value => `${rubles.format(value)} ₽`;

let active = -1;
let stage = "";
let catalogStart = 1;
let approachTravel = 1;
let spacing = 0;
let shelfWidth = 0;
let sceneHeight = 0;
let imageHeight = 0;
let capLift = 0;
let animationFrame = 0;
let navigationFrame = 0;

let displayedProgress = 0;
let lastRenderAt = 0;

const items = fragrances.map((fragrance, position) => {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "flacon";
  button.setAttribute("aria-label", fragrance.name);
  button.tabIndex = -1;
  button.style.setProperty("--cap-offset", `${fragrance.capOffset}%`);
  button.innerHTML = `
    <span class="flacon-art">
      <img class="body" src="assets/gallery/bottles/${fragrance.id}-body.webp" alt="">
      <img class="cap" src="assets/gallery/bottles/${fragrance.id}-cap.webp" alt="">
    </span>`;
  button.addEventListener("click", () => select(position));
  shelf.append(button);

  const description = document.createElement("article");
  description.className = "description";
  description.setAttribute("aria-hidden", "true");
  description.innerHTML = `
    <p class="house">${fragrance.house}</p>
    <h2>${fragrance.label}</h2>
    <p class="notes">${fragrance.description}</p>
    <p class="full-price"><span>Полный флакон</span><strong>${priceText(fragrance.bottlePrice)}</strong></p>`;
  descriptions.append(description);
  return { button, description };
});

const sampleRows = [2, 5, 10].map(volume => {
  const row = document.createElement("li");
  row.innerHTML = `
    <span class="sample-vial" aria-hidden="true"><img src="assets/gallery/vial-${volume}.webp" alt=""><span></span></span>
    <span class="sample-volume">${volume} мл</span>
    <strong></strong>`;
  samples.append(row);
  return { label: row.querySelector(".sample-vial span"), price: row.querySelector("strong") };
});

function select(position) {
  window.scrollTo({
    top: catalogStart + clamp(position, 0, last) * shelfTravel / last,
    behavior: reducedMotion.matches ? "instant" : "smooth",
  });
}

function stopNavigation() {
  cancelAnimationFrame(navigationFrame);
  navigationFrame = 0;
}

function followChapter(event) {
  if (reducedMotion.matches || scene.dataset.video === "unavailable") return;
  if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
  event.preventDefault();
  stopNavigation();

  const start = window.scrollY;
  const target = document.querySelector(chapterLink.hash).offsetTop;
  const distance = target - start;
  if (Math.abs(distance) < 1) return;

  const duration = clamp(Math.abs(distance) / approachTravel * 16000, 900, 16000);
  const startedAt = performance.now();
  function advance(now) {
    const progress = clamp((now - startedAt) / duration, 0, 1);
    const eased = (1 - Math.cos(progress * Math.PI)) / 2;
    window.scrollTo({ top: start + distance * eased, behavior: "instant" });
    navigationFrame = progress < 1 ? requestAnimationFrame(advance) : 0;
  }
  navigationFrame = requestAnimationFrame(advance);
}

function updateStage(nextStage) {
  if (nextStage === stage) return;

  stage = nextStage;
  scene.dataset.stage = stage;
  catalog.inert = stage !== "catalog";
  shelf.inert = catalog.inert;

  const links = {
    arrival: ["#interior", "Войти в галерею", "↘"],
    interior: ["#collection", "К выбору аромата", "↘"],
    catalog: ["#interior", "В галерею", "↖"],
  };
  const [href, label, arrow] = links[stage];
  chapterLink.href = href;
  chapterLink.innerHTML = `${label} <span aria-hidden="true">${arrow}</span>`;
}

function renderShelf(time, position, opening, atShelf) {
  const localTime = time - shelfApproachStart;
  const visible = atShelf || localTime >= shelfTrack[0][0];
  const opacity = atShelf ? 1 : clamp((localTime - shelfTrack[0][0]) / .67, 0, 1);
  shelf.style.setProperty("--shelf-opacity", String(opacity));
  if (!visible) return;

  const next = atShelf ? -1 : shelfTrack.findIndex(([timestamp]) => timestamp > localTime);
  let [, line, scale, gap] = shelfTrack.at(-1);
  if (next > 0) {
    const [from, fromLine, fromScale, fromGap] = shelfTrack[next - 1];
    const [to, toLine, toScale, toGap] = shelfTrack[next];
    const progress = (localTime - from) / (to - from);
    line = fromLine + (toLine - fromLine) * progress;
    scale = fromScale + (toScale - fromScale) * progress;
    gap = fromGap + (toGap - fromGap) * progress;
  }
  const shelfLine = clamp((sceneHeight - imageHeight) / 2 + imageHeight * line, 0, sceneHeight);
  const centered = 1 - clamp((localTime - 3.8) / 3, 0, 1);
  const camera = atShelf ? position : centered * last / 2;
  const imageWidth = imageHeight * 16 / 9;
  const trackedSpacing = imageWidth * gap;
  const arrival = clamp((localTime - 5.4) / 1.6, 0, 1);
  const distanceBetweenBottles = atShelf ? spacing : trackedSpacing + (spacing - trackedSpacing) * arrival;
  shelf.style.setProperty("--shelf-line", `${shelfLine}px`);

  items.forEach(({ button }, index) => {
    const distance = index - camera;
    const emphasis = Math.max(0, 1 - Math.abs(distance));
    const x = distance * distanceBetweenBottles;
    button.style.setProperty("--x", `${x}px`);
    button.style.setProperty("--size", String(scale * (.69 + emphasis * .31)));
    button.style.setProperty("--light", String(.62 + emphasis * .38));
    button.style.setProperty("--lift", `${-(emphasis ** 2) * opening * capLift}px`);
    button.style.zIndex = String(1 + Math.round(emphasis * 10));
    button.tabIndex = atShelf && Math.abs(x) < shelfWidth * .51 ? 0 : -1;
  });
}

function render(now) {
  animationFrame = 0;
  const scroll = window.scrollY;
  const targetProgress = clamp(scroll / approachTravel, 0, 1);
  const reduced = reducedMotion.matches;
  const smoothFlight = !reduced && scene.dataset.video !== "unavailable";
  const elapsed = Math.min(48, now - lastRenderAt);
  lastRenderAt = now;
  // Keep the camera moving between discrete wheel events.
  if (smoothFlight && Math.abs(targetProgress - displayedProgress) > .0009) {
    displayedProgress += (targetProgress - displayedProgress) * (1 - Math.exp(-elapsed / 85));
    scheduleRender();
  } else {
    displayedProgress = targetProgress;
  }
  const progress = displayedProgress;
  const room = progress >= roomMoment - .04;
  const catalogVisible = scroll >= approachTravel && progress > .997;
  const reveal = catalogVisible
    ? reduced ? 1 : clamp((scroll + 1 - approachTravel) / (catalogStart - approachTravel), 0, 1)
    : 0;

  updateStage(catalogVisible ? "catalog" : room ? "interior" : "arrival");
  catalog.style.setProperty("--catalog-opacity", String(reveal));
  catalog.style.setProperty("--panel-offset", `${(1 - reveal) * 24}px`);
  arrivalCaption.style.opacity = String(reduced ? Number(stage === "arrival") : clamp(1 - progress * 8, 0, 1));
  interiorCaption.style.opacity = String(reduced ? Number(stage === "interior") : clamp(1 - Math.abs(progress - roomMoment) / .045, 0, 1));

  if (smoothFlight && window.galleryFlight) {
    window.galleryFlight.seek(progress * 39.958);
  }

  const position = clamp((scroll - catalogStart) / shelfTravel, 0, 1) * last;
  const selected = Math.round(position);
  renderShelf(smoothFlight ? (window.galleryFlight?.paintedTime ?? 0) : 0, reduced ? selected : position, reveal, catalogVisible);

  if (selected === active) return;
  if (active >= 0) {
    items[active].button.removeAttribute("aria-current");
    items[active].description.setAttribute("aria-hidden", "true");
  }
  active = selected;
  items[active].button.setAttribute("aria-current", "true");
  items[active].description.removeAttribute("aria-hidden");

  const fragrance = fragrances[active];
  sampleRows.forEach(({ label, price }, index) => {
    label.textContent = fragrance.house;
    price.textContent = priceText(fragrance.prices[index]);
  });
  counter.textContent = `${String(active + 1).padStart(2, "0")} / ${fragrances.length}`;
  previous.disabled = active === 0;
  next.disabled = active === last;
}

function scheduleRender() {
  if (!animationFrame) animationFrame = requestAnimationFrame(render);
}

function measure() {
  const height = scene.clientHeight;
  sceneHeight = height;
  shelfWidth = shelf.clientWidth;
  approachTravel = height * (reducedMotion.matches ? 1.6 : 4.8);
  catalogStart = approachTravel + (reducedMotion.matches ? 1 : height * .26);
  journey.style.setProperty("--interior-start", `${approachTravel * roomMoment}px`);
  journey.style.setProperty("--catalog-start", `${Math.ceil(catalogStart)}px`);

  // Match the bottle baseline to the glass surface after the video crop.
  imageHeight = Math.max(height, shelfWidth * 9 / 16);
  const shelfLine = clamp((height - imageHeight) / 2 + imageHeight * .54, 0, height);
  shelf.style.setProperty("--shelf-height", `${shelfLine * .68}px`);
  capLift = Math.min(68, shelfLine * .15);
  spacing = clamp(shelfWidth * .31, 108, 252);
  scheduleRender();
}

chapterLink.addEventListener("click", followChapter);
window.addEventListener("wheel", stopNavigation, { passive: true });
window.addEventListener("pointerdown", stopNavigation, { passive: true });
window.addEventListener("touchstart", stopNavigation, { passive: true });
window.addEventListener("keydown", stopNavigation);
previous.addEventListener("click", () => select(active - 1));
next.addEventListener("click", () => select(active + 1));
window.addEventListener("scroll", scheduleRender, { passive: true });
window.addEventListener("resize", measure);
reducedMotion.addEventListener("change", () => {
  stopNavigation();
  measure();
});
measure();
