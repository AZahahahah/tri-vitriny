const canvas = document.getElementById("flight");
const context = canvas.getContext("2d", { alpha: false });
const status = document.getElementById("flight-status");
const portrait = window.matchMedia("(max-aspect-ratio: 3/4)");
const video = document.createElement("video");
video.muted = true;
video.defaultMuted = true;
video.playsInline = true;
video.preload = "auto";
video.className = "flight-decoder";
canvas.after(video);

let wantedTime = 0;
let paintedTime = 0;
let format;
let frameReady = false;
let loadingNotice;

function showLoading() {
  if (loadingNotice) return;
  loadingNotice = setTimeout(() => {
    status.textContent = "Загружается пролёт";
    status.hidden = false;
  }, 650);
}

function hideLoading() {
  clearTimeout(loadingNotice);
  loadingNotice = undefined;
  status.hidden = true;
}

function showFallback() {
  hideLoading();
  delete canvas.dataset.ready;
  scene.dataset.video = "unavailable";
  status.textContent = "Пролёт недоступен. Галерею и полку можно посмотреть дальше.";
  status.hidden = false;
  scheduleRender();
}

function move() {
  if (reducedMotion.matches || scene.dataset.video === "unavailable") return;
  const nextFormat = portrait.matches ? "portrait" : "wide";
  if (format !== nextFormat) {
    format = nextFormat;
    frameReady = false;
    showLoading();
    video.src = `assets/gallery/flight-v9/${format}.mp4`;
    return;
  }

  if (video.readyState < 1 || video.seeking) return;
  const time = Math.max(0, Math.min(wantedTime, video.duration - .04));
  if (Math.abs(time - video.currentTime) > .033) {
    if (Math.abs(time - paintedTime) > .75) showLoading();
    video.currentTime = time;
  }
}

function paint() {
  if (video.readyState < 2 || video.seeking) return;
  if (!frameReady || Math.abs(paintedTime - video.currentTime) > .015) {
    if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
    }
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.dataset.ready = "true";
    frameReady = true;
    paintedTime = video.currentTime;
    hideLoading();
    scheduleRender();
  }
  move();
}

video.addEventListener("loadedmetadata", move);
video.addEventListener("loadeddata", paint);
video.addEventListener("seeked", paint);
video.addEventListener("error", showFallback);
portrait.addEventListener("change", move);
window.galleryFlight = {
  seek(time) {
    wantedTime = time;
    move();
  },
  get paintedTime() { return paintedTime; },
};
scheduleRender();
