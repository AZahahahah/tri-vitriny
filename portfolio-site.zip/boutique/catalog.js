const fragrances = [
  {
    "id": "santal-33",
    "house": "Le Labo",
    "label": "Santal 33",
    "name": "Le Labo Santal 33",
    "description": "Сухой сандал, кожа и пряный кардамон.",
    "bottlePrice": 22600,
    "prices": [
      750,
      1790,
      3290
    ],
    "capOffset": 10.81
  },
  {
    "id": "diptyque-leau-papier",
    "house": "Diptyque",
    "label": "L’Eau Papier",
    "name": "Diptyque L’Eau Papier",
    "description": "Мягкий мускус, рис и светлая древесина.",
    "bottlePrice": 17800,
    "prices": [
      630,
      1450,
      2670
    ],
    "capOffset": 10.81
  },
  {
    "id": "xerjoff-torino21",
    "house": "Xerjoff",
    "label": "Torino21",
    "name": "Xerjoff Torino21",
    "description": "Прохладная мята, цитрусы и пряные травы.",
    "bottlePrice": 25700,
    "prices": [
      990,
      2180,
      3990
    ],
    "capOffset": 10.81
  },
  {
    "id": "maison-francis-kurkdjian-gentle-fluidity-silver",
    "house": "Maison Francis Kurkdjian",
    "label": "Gentle Fluidity Silver",
    "name": "Maison Francis Kurkdjian Gentle Fluidity Silver",
    "description": "Прохладный можжевельник и сухая мускусная свежесть.",
    "bottlePrice": 29600,
    "prices": [
      1040,
      2340,
      4280
    ],
    "capOffset": 10.59
  },
  {
    "id": "parfums-de-marly-valaya",
    "house": "Parfums de Marly",
    "label": "Valaya",
    "name": "Parfums de Marly Valaya",
    "description": "Персик, белые цветы и воздушный мускус.",
    "bottlePrice": 31900,
    "prices": [
      1190,
      2680,
      4860
    ],
    "capOffset": 8.82
  },
  {
    "id": "creed-silver-mountain-water",
    "house": "Creed",
    "label": "Silver Mountain Water",
    "name": "Creed Silver Mountain Water",
    "description": "Цитрусы, зелёный чай и прохладный мускус.",
    "bottlePrice": 28300,
    "prices": [
      960,
      2160,
      3870
    ],
    "capOffset": 10.26
  }
];
