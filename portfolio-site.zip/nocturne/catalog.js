const fragrances = [
  {
    "id": "cedrus",
    "name": "Chloé Cedrus",
    "description": "Сухой кедр и ветивер согреваются сандалом. Кардамон и розовый перец добавляют лёгкую пряность.",
    "traits": [
      "Древесный",
      "Сухой",
      "Пряный"
    ],
    "prices": [
      590,
      1290,
      2290
    ],
    "house": "Chloé",
    "label": "Cedrus",
    "finish": "ivory",
    "bottlePrice": 15890
  },
  {
    "id": "blanche",
    "name": "Byredo Blanche",
    "description": "Свежесть белой рубашки, нежная роза и воздушный мускус. Мягкий сандал постепенно согревает аромат на коже.",
    "traits": [
      "Чистый",
      "Цветочный",
      "Мускусный"
    ],
    "prices": [
      690,
      1490,
      2690
    ],
    "house": "BYREDO",
    "label": "Blanche",
    "finish": "ivory",
    "bottlePrice": 22190
  },
  {
    "id": "henry-i",
    "name": "Henry Lab I",
    "description": "Прохладная цитрусовая цедра и розовый перец переходят в сухой ветивер и мягкий мускус.",
    "traits": [
      "Древесный",
      "Цитрусовый",
      "Мускусный"
    ],
    "prices": [
      490,
      1090,
      1990
    ],
    "house": "HENRY LAB",
    "label": "I",
    "finish": "ivory",
    "bottlePrice": 11890
  },
  {
    "id": "sunmusk",
    "name": "HFC Sunmusk",
    "description": "Бергамот и нероли освежают мягкий белый мускус. Серая амбра добавляет тепла.",
    "traits": [
      "Мускусный",
      "Цветочный",
      "Свежий"
    ],
    "prices": [
      780,
      1690,
      3090
    ],
    "house": "HFC",
    "label": "Sunmusk",
    "finish": "gold",
    "bottlePrice": 24890
  },
  {
    "id": "ambre-blanc",
    "name": "Maison Rebatchi Ambre Blanc",
    "description": "Пудровый ирис смягчает тёплую амбру и ваниль. В шлейфе остаётся сухой кедр.",
    "traits": [
      "Амбровый",
      "Пудровый",
      "Древесный"
    ],
    "prices": [
      620,
      1360,
      2460
    ],
    "house": "REBATCHI",
    "label": "Ambre Blanc",
    "finish": "gold",
    "bottlePrice": 16990
  },
  {
    "id": "amouage-guidance",
    "name": "Amouage Guidance",
    "description": "Сочная груша, фундук и ладан сменяются розой и османтусом. Сандал и ваниль дают кремовый шлейф.",
    "traits": [
      "Цветочный",
      "Амбровый",
      "Фруктовый",
      "Шлейфовый"
    ],
    "prices": [
      990,
      2190,
      3990
    ],
    "house": "AMOUAGE",
    "label": "Guidance",
    "finish": "rose",
    "bottlePrice": 32990
  },
  {
    "id": "brandt-guava-sorbet",
    "name": "House of Brandt Guava Sorbet",
    "description": "Гуава и маракуйя напоминают тропический сорбет с кислинкой. Белый жасмин смягчает фруктовую сладость.",
    "traits": [
      "Фруктовый",
      "Тропический",
      "Сладкий"
    ],
    "prices": [
      730,
      1570,
      2890
    ],
    "house": "HOUSE OF BRANDT",
    "label": "Guava Sorbet",
    "finish": "rose",
    "bottlePrice": 20890
  },
  {
    "id": "guerlain-neroli-outrenoir",
    "name": "Guerlain Néroli Outrenoir",
    "description": "Искристый нероли и бергамот раскрываются на фоне крепкого чёрного чая с дымком.",
    "traits": [
      "Цитрусовый",
      "Чайный",
      "Дымный"
    ],
    "prices": [
      890,
      1970,
      3590
    ],
    "house": "GUERLAIN",
    "label": "Néroli Outrenoir",
    "finish": "onyx",
    "bottlePrice": 28990
  },
  {
    "id": "trussardi-spiga",
    "name": "Trussardi Spiga",
    "description": "Тёплые медовые соты и жасмин переходят в пудровый шлейф с мягкой сладостью бобов тонка.",
    "traits": [
      "Медовый",
      "Цветочный",
      "Пудровый"
    ],
    "prices": [
      530,
      1190,
      2150
    ],
    "house": "TRUSSARDI",
    "label": "Spiga",
    "finish": "ivory",
    "bottlePrice": 13990
  },
  {
    "id": "ella-k-camelia-k",
    "name": "Ella K Camélia K",
    "description": "Сочная питайя и красный апельсин звучат ярче благодаря острому имбирю. В финале остаётся тепло бобов тонка.",
    "traits": [
      "Фруктовый",
      "Пряный",
      "Сочный"
    ],
    "prices": [
      820,
      1860,
      3390
    ],
    "house": "ELLA K",
    "label": "Camélia K",
    "finish": "ruby",
    "bottlePrice": 26890
  },
  {
    "id": "eldo-you-or-someone-like-you",
    "name": "Etat Libre d’Orange You Or Someone Like You",
    "description": "Холодная мята, лимон и скошенная трава напоминают летний сад. Прозрачная роза смягчает зелень.",
    "traits": [
      "Зелёный",
      "Свежий",
      "Травяной"
    ],
    "prices": [
      560,
      1240,
      2240
    ],
    "house": "ÉTAT LIBRE D’ORANGE",
    "label": "You Or Someone Like You",
    "finish": "ivory",
    "bottlePrice": 12990
  },
  {
    "id": "parfum-dempire-corsica-furiosa",
    "name": "Parfum d’Empire Corsica Furiosa",
    "description": "Терпкий томатный лист и дикая мята звучат на смолистой базе мастикового дерева.",
    "traits": [
      "Зелёный",
      "Смолистый",
      "Терпкий"
    ],
    "prices": [
      650,
      1430,
      2550
    ],
    "house": "PARFUM D’EMPIRE",
    "label": "Corsica Furiosa",
    "finish": "petrol",
    "bottlePrice": 17990
  },
  {
    "id": "amouage-opus-vii",
    "name": "Amouage Opus VII",
    "description": "Дым агарового дерева и сухая кожа звучат на землистом фоне пачули и тёплой серой амбры.",
    "traits": [
      "Кожаный",
      "Дымный",
      "Древесный"
    ],
    "prices": [
      940,
      2070,
      3790
    ],
    "house": "AMOUAGE",
    "label": "Opus VII",
    "finish": "onyx",
    "bottlePrice": 30990
  },
  {
    "id": "frederic-malle-synthetic-jungle",
    "name": "Frédéric Malle Synthetic Jungle",
    "description": "Пряный базилик и ландыш напоминают сад после дождя. Жасмин смягчает зелень, пачули добавляют землистости.",
    "traits": [
      "Зелёный",
      "Цветочный",
      "Влажный"
    ],
    "prices": [
      850,
      1790,
      3290
    ],
    "house": "FRÉDÉRIC MALLE",
    "label": "Synthetic Jungle",
    "finish": "onyx",
    "bottlePrice": 27990
  },
  {
    "id": "atelier-des-ors-lune-feline",
    "name": "Atelier des Ors Lune Féline",
    "description": "Кардамон и корица согревают густую таитянскую ваниль. Перуанский бальзам придаёт шлейфу смолистую глубину.",
    "traits": [
      "Ванильный",
      "Пряный",
      "Бальзамический"
    ],
    "prices": [
      790,
      1740,
      3190
    ],
    "house": "ATELIER DES ORS",
    "label": "Lune Féline",
    "finish": "gold",
    "bottlePrice": 25990
  }
];
